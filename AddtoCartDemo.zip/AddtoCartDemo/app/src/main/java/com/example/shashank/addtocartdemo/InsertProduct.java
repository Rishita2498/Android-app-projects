package com.example.shashank.addtocartdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.shashank.addtocartdemo.model.ShoppingHelper;

public class InsertProduct extends AppCompatActivity {
    EditText pname,pprice,pdesc,pquant;
    Button regp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_product);
        pname=findViewById(R.id.pname);
        pprice=findViewById(R.id.pprice);
        pdesc=findViewById(R.id.pdesc);
        pquant=findViewById(R.id.pquant);
        regp=findViewById(R.id.regp);
        regp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShoppingHelper sh=new ShoppingHelper(InsertProduct.this);
                sh.insertproduct(pname.getText().toString(),
                        Integer.parseInt(pprice.getText().toString()),
                        Integer.parseInt(pquant.getText().toString()),
                        pdesc.getText().toString());
            }
        });

    }
}
