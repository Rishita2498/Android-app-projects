package com.example.shashank.addtocartdemo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.shashank.addtocartdemo.model.ShoppingHelper;

public class MyCart extends AppCompatActivity {
SharedPreferences sp;
ListView ml;
ShoppingHelper sh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_cart);
        sp=(SharedPreferences)getSharedPreferences("atc",MODE_PRIVATE);
        ml=findViewById(R.id.ml);
        sh=new ShoppingHelper(MyCart.this);
        if(sh.mycart(sp.getString("uemail",null)).get("pid")==null)
        {

        }
        else
            {

            ArrayAdapter ad = new ArrayAdapter(MyCart.this, android.R.layout.simple_list_item_1, sh.mycart(sp.getString("uemail", null)).get("pid"));
           ml.setAdapter(ad);
           ml.setOnItemClickListener(new AdapterView.OnItemClickListener() {
               @Override
               public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                   AlertDialog.Builder adb=new AlertDialog.Builder(MyCart.this);
                   adb.setTitle("Product Details");
                   adb.setMessage("Name : "+sh.viewproductdetails(sh.mycart(sp.getString("uemail",null)).
                           get("pid").get(position)).get("pname").get(position).toString());
                   adb.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                       @Override
                       public void onClick(DialogInterface dialog, int which) {


                       }
                   });
                   adb.setCancelable(false);
                   adb.show();

               }
           });
        }
    }
}
