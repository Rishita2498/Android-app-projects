package com.example.shashank.addtocartdemo;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.shashank.addtocartdemo.model.ShoppingHelper;

import java.util.ArrayList;
import java.util.HashMap;

public class ProductDetails extends AppCompatActivity {
ShoppingHelper sh;
HashMap<String,ArrayList<String>> pd;
TextView pdtv;
Spinner pq;
Button atc;
ArrayList<String> apq;
SharedPreferences sp;
ArrayAdapter ad;
    int tpq;
    Bundle b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);
        b=this.getIntent().getExtras();
        apq=new ArrayList<>();
        sh=new ShoppingHelper(ProductDetails.this);
        sp=(SharedPreferences)getSharedPreferences("atc",MODE_PRIVATE);

        pd=sh.viewproductdetails(b.getString("pid",null));
        pdtv=findViewById(R.id.pdtv);
        atc=findViewById(R.id.atc);
        pq=findViewById(R.id.pq);
        tpq=Integer.parseInt(pd.get("pquant").get(0).toString());
        pdtv.setText("PID : "+b.getString("pid",null)+
        "\n Product Name : "+pd.get("pname").get(0).toString()
        +"\nPrice : "+pd.get("pprice").get(0).toString()+
        "\nDescription : "+pd.get("pdesc").get(0).toString());
        SharedPreferences.Editor ed=sp.edit();
        ed.putString("pid",b.getString("pid",null));
        ed.commit();
        if(tpq==0)
        {
            pdtv.append("\n\n Sorry You cannot Add");
            pdtv.setTextSize(25.0f);
            atc.setVisibility(View.GONE);
            pq.setVisibility(View.GONE);
        }
        else
        {
            for(int i=1;i<=tpq;i++)
            {
                apq.add(i+"");
            }
            ad=new ArrayAdapter(ProductDetails.this,
                    android.R.layout.simple_dropdown_item_1line,apq);
            pq.setAdapter(ad);
            atc.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int tpresent=tpq-Integer.parseInt(pq.getSelectedItem().toString());
                    sh.productupdate(Integer.parseInt(sp.getString("pid",null)),tpresent);
               sh.addcart(Integer.parseInt(sp.getString("pid",null)),
                       sp.getString("uemail",null), Integer.parseInt(pq.getSelectedItem().toString()));

                }
            });

        }






    }
}
