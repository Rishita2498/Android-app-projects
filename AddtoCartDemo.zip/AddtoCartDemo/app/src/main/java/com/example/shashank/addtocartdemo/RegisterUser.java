package com.example.shashank.addtocartdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.shashank.addtocartdemo.model.ShoppingHelper;

public class RegisterUser extends AppCompatActivity {
    EditText uname,upass,uemail,uphone;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);
        uname=findViewById(R.id.uname);
        upass=findViewById(R.id.upass);
        uemail=findViewById(R.id.uemail);
        uphone=findViewById(R.id.uphone);
        submit=findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShoppingHelper sh=new ShoppingHelper(RegisterUser.this);
                sh.insertuser(uname.getText().toString(),upass.getText().toString(),uemail.getText().toString(),uemail.getText().toString());


            }
        });
    }
}
