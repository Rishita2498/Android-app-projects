package com.example.shashank.addtocartdemo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.shashank.addtocartdemo.model.ShoppingHelper;

public class UserLogin extends AppCompatActivity {
EditText uname,upass;
Button login,register;
SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        uname=findViewById(R.id.uname);
        upass=findViewById(R.id.upass);
        sp=(SharedPreferences)getSharedPreferences("atc",MODE_PRIVATE);

        login=findViewById(R.id.login);
        register=findViewById(R.id.register);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ShoppingHelper sh=new ShoppingHelper(UserLogin.this);
                if (sh.validateuser(uname.getText().toString(),upass.getText().toString()))
                {

                    Intent i=new Intent(UserLogin.this,ViewProducts.class);
                    SharedPreferences.Editor ed=sp.edit();
                    ed.putString("uemail",uname.getText().toString());
                    ed.commit();
                    startActivity(i);
                    Toast.makeText(UserLogin.this, "you are valid", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(UserLogin.this, "You are not valid", Toast.LENGTH_SHORT).show();
                }
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(UserLogin.this,RegisterUser.class);
                startActivity(i);

            }
        });
    }
}
