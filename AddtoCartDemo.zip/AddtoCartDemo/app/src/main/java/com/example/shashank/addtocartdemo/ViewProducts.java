package com.example.shashank.addtocartdemo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.shashank.addtocartdemo.model.AlertDemo;
import com.example.shashank.addtocartdemo.model.ShoppingHelper;

public class ViewProducts extends AppCompatActivity {
ListView lv;
ShoppingHelper sh;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
getMenuInflater().inflate(R.menu.cart,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.i1)
        {
            Intent aa=new Intent(ViewProducts.this,MyCart.class);
            startActivity(aa);

        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_products);
        lv=findViewById(R.id.vapl);
        sh=new ShoppingHelper(ViewProducts.this);
        ArrayAdapter ad=new ArrayAdapter(ViewProducts.this,
                android.R.layout.simple_list_item_1,sh.viewproduct().get("pname"));
        lv.setAdapter(ad);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder adb=new AlertDialog.Builder(ViewProducts.this);
                adb.setTitle("Product Details");
                adb.setMessage("Name : "+sh.viewproduct().get("pname").get(position).toString());
                adb.setPositiveButton("View Product in Detail", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent aa=new Intent(ViewProducts.this,ProductDetails.class);
                        Bundle b=new Bundle();
                        b.putString("pid",sh.viewproduct().get("pid").get(position).toString());
                        aa.putExtras(b);
                        startActivity(aa);

                    }
                });
                adb.setCancelable(false);
                adb.show();



            }
        });
    }
}
