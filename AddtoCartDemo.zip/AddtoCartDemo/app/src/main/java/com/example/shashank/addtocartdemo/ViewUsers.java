package com.example.shashank.addtocartdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.shashank.addtocartdemo.model.AlertDemo;
import com.example.shashank.addtocartdemo.model.ShoppingHelper;

public class ViewUsers extends AppCompatActivity {
ListView vau;
    ShoppingHelper sh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_users);
        vau=findViewById(R.id.vau);
         sh=new ShoppingHelper(ViewUsers.this);
        ArrayAdapter ad=new ArrayAdapter(ViewUsers.this,android.R.layout.simple_list_item_1,sh.viewuser().get("uname"));
        vau.setAdapter(ad);

        vau.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                AlertDemo.alert(ViewUsers.this,"User Details",
                        "Name : "+sh.viewuser().get("uname").get(position).toString()+
                                "\nEmail : "+sh.viewuser().get("uemail").get(position).toString()+
                "\nPhone : "+sh.viewuser().get("uphone").get(position).toString());

            }
        });
    }
}
