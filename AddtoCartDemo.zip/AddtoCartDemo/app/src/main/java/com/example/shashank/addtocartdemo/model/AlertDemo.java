package com.example.shashank.addtocartdemo.model;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class AlertDemo {

    public static void alert(Context con,String title, String message)
    {
        AlertDialog.Builder adb=new AlertDialog.Builder(con);
        adb.setTitle(title);
        adb.setMessage(message);
        adb.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        adb.setCancelable(false);
        adb.show();
    }
}
