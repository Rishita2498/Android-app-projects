package com.example.shashank.addtocartdemo.model;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class ShoppingHelper extends SQLiteOpenHelper
{
    Context con;
    SharedPreferences sp;

    public ShoppingHelper(Context context) {
        super(context, "SHOPPINGDB", null, 1);
        con=context;//defining context
        sp=(SharedPreferences)con.getSharedPreferences("atc",con.MODE_PRIVATE);

    }

    public boolean validateuser(String e,String p)
    {
        SQLiteDatabase db=this.getReadableDatabase();
        String[] selection={e,p};
        String[] col={"uid","uemail","upass"};

        Cursor ruser=db.query("user",col,"uemail=? and upass=?",selection,
                null,null,null);
        if(ruser.getCount()!=0)
        {

            return true;
        }
        return false;

    }
    public void productupdate(int pid,int tquant)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues pcv=new ContentValues();
        pcv.put("pquant",tquant);
        db.update("product",pcv,"pid=?",new String[]{pid+""});
        db.close();

    }
    public void addcart(int pid,String uid,int quant)
    {

        SQLiteDatabase db1=this.getWritableDatabase();

        ContentValues acv=new ContentValues();

        acv.put("pid",pid);
        acv.put("uname",uid);
        acv.put("pquant",quant);
        db1.insert("cart",null,acv);
        db1.close();
        Toast.makeText(con, "Added to cart", Toast.LENGTH_SHORT).show();
        db1.close();
    }

    public HashMap<String,ArrayList<String>> viewuser()

    {
        SQLiteDatabase db=this.getReadableDatabase();
        //String[] selection={e};
        String[] col={"uid","uname","uemail","uphone"};
        Cursor rproduct=db.query("user",col,null,null,
                null,null,null);
        HashMap<String,ArrayList<String>> hm=new HashMap<>();
        ArrayList<String> uid=new ArrayList<>();
        ArrayList<String> uname=new ArrayList<>();
        ArrayList<String> uemail=new ArrayList<>();
        ArrayList<String> uphone=new ArrayList<>();

        if(rproduct.moveToFirst())
            do {
                uid.add(rproduct.getInt(0)+"");
                uname.add(rproduct.getString(1));
                uemail.add(rproduct.getString(2)+"");
                uphone.add(rproduct.getString(3));


            }while(rproduct.moveToNext());
        hm.put("uid",uid);
        hm.put("uname",uname);
        hm.put("uphone",uphone);
        hm.put("uemail",uemail);

        return hm;

    }
    public HashMap<String,ArrayList<String>> mycart(String uid)

    {
        SQLiteDatabase db=this.getReadableDatabase();
        String[] selection={uid};
        String[] ccol={"uname","pid","pquant"};
        Cursor rcart=db.query("cart",ccol,"uname=?",selection,
                null,null,null);
        HashMap<String,ArrayList<String>> hm=new HashMap<>();

      ArrayList<String> pid=new ArrayList<>();
        if(rcart.getCount()!=0)
        {
            if(rcart.moveToFirst())
                do {
                pid.add(rcart.getInt(1)+"");

                }while (rcart.moveToNext());
            hm.put("pid",pid);
            return hm;
        }
        else
        {
            Toast.makeText(con, "No Products", Toast.LENGTH_SHORT).show();
            return null;
        }




    }
    public HashMap<String,ArrayList<String>> viewproductdetails(String pid)

    {
        SQLiteDatabase db=this.getReadableDatabase();
        String[] selection={pid};
        String[] col={"pid","pname","pprice","pquant","pdesc"};
        Cursor rproduct=db.query("product",col,"pid=?",selection,
                null,null,null);
        HashMap<String,ArrayList<String>> hm=new HashMap<>();
        ArrayList<String> pname=new ArrayList<>();
        ArrayList<String> pdesc=new ArrayList<>();
        ArrayList<String> pquant=new ArrayList<>();
        ArrayList<String> pprice=new ArrayList<>();
        if(rproduct.moveToFirst())
            do {
                pname.add(rproduct.getString(1));
                pprice.add(rproduct.getInt(2)+"");
                pquant.add(rproduct.getInt(3)+"");
                pdesc.add(rproduct.getString(4));


            }while(rproduct.moveToNext());
        hm.put("pname",pname);
        hm.put("pprice",pprice);
        hm.put("pquant",pquant);
        hm.put("pdesc",pdesc);

        return hm;

    }
    public HashMap<String,ArrayList<String>> viewproduct()

    {
        SQLiteDatabase db=this.getReadableDatabase();
        //String[] selection={e};
        String[] col={"pid","pname","pprice","pquant","pdesc"};
        Cursor rproduct=db.query("product",col,null,null,
                null,null,null);
        HashMap<String,ArrayList<String>> hm=new HashMap<>();
        ArrayList<String> pid=new ArrayList<>();
        ArrayList<String> pname=new ArrayList<>();
        ArrayList<String> pdesc=new ArrayList<>();
        ArrayList<String> pquant=new ArrayList<>();
        ArrayList<String> pprice=new ArrayList<>();
        if(rproduct.moveToFirst())
            do {
            pid.add(rproduct.getInt(0)+"");
            pname.add(rproduct.getString(1));
            pprice.add(rproduct.getInt(2)+"");
            pquant.add(rproduct.getInt(3)+"");
            pdesc.add(rproduct.getString(4));


            }while(rproduct.moveToNext());
        hm.put("pid",pid);
        hm.put("pname",pname);
        hm.put("pprice",pprice);
        hm.put("pquant",pquant);
        hm.put("pdesc",pdesc);

        return hm;

    }
    public boolean checkuser(String e)
    {
        SQLiteDatabase db=this.getReadableDatabase();
        String[] selection={e};
        String[] col={"uemail"};
        Cursor ruser=db.query("user",col,"uemail=?",selection,
                null,null,null);
        if(ruser.getCount()==0)
        {
            return true;
        }
return false;
    }
    public void insertuser(String uname,String upass,String uphone,String uemail)
    {

        SQLiteDatabase db=this.getWritableDatabase();
        if(checkuser(uemail)) {


            ContentValues cv = new ContentValues();
            cv.put("uname", uname);
            cv.put("upass", upass);
            cv.put("uphone", uphone);
            cv.put("uemail", uemail);
            db.insert("user", null, cv);
            db.close();
            Toast.makeText(con, "user registered", Toast.LENGTH_SHORT).show();

        }
        else
        {
            Toast.makeText(con, "no duplicate ", Toast.LENGTH_SHORT).show();
        }
    }
    public void insertproduct (String pname,int pprice,int pquant,String pdesc)
    {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("pname", pname);
        cv.put("pprice",pprice);
        cv.put("pquant",pquant);
        cv.put("pdesc",pdesc);
        db.insert("product",null,cv) ;
        db.close();
        Toast.makeText(con, "product registered successfully", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String usertb="create table user (uid integer primary key autoincrement,uname text " +
                "not null ," +
                "upass text not null,uphone text not null, uemail text not null );";
        String ptb="create table product (pid integer primary key autoincrement,pname text " +
                " not null," +
                "pprice integer not null,pdesc text " +
                ",pquant integer not null);";
        String ctb="create table cart(cid integer primary key autoincrement ,uname text," +
                "pid integer, pquant integer);";
        db.execSQL(usertb);
        db.execSQL(ptb);
        db.execSQL(ctb);



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
