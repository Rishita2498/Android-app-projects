package it.vjit.foodorderingsystem;

public class HotelDetail {
int sno;
String hotelname;
String hotellocation;
String morning,afternoon,evening,deptime;

public String getDeptime() {
	return deptime;
}
public void setDeptime(String deptime) {
	this.deptime = deptime;
}
public String getMorning() {
	return morning;
}
public void setMorning(String morning) {
	this.morning = morning;
}
public String getAfternoon() {
	return afternoon;
}
public void setAfternoon(String afternoon) {
	this.afternoon = afternoon;
}
public String getEvening() {
	return evening;
}
public void setEvening(String evening) {
	this.evening = evening;
}
String hotelphrase;
public int getSno() {
	return sno;
}
public void setSno(int sno) {
	this.sno = sno;
}
public String getHotelname() {
	return hotelname;
}
public void setHotelname(String hotelname) {
	this.hotelname = hotelname;
}
public String getHotellocation() {
	return hotellocation;
}
public void setHotellocation(String hotellocation) {
	this.hotellocation = hotellocation;
}
public String getHotelphrase() {
	return hotelphrase;
}
public void setHotelphrase(String hotelphrase) {
	this.hotelphrase = hotelphrase;
}


}
