package it.vjit.foodorderingsystem;

public class TrainDetail {
int sno;
String name;
String depttime;
String morning,afternoon,night;


public String getMorning() {
	return morning;
}
public void setMorning(String morning) {
	this.morning = morning;
}
public String getAfternoon() {
	return afternoon;
}
public void setAfternoon(String afternoon) {
	this.afternoon = afternoon;
}
public String getNight() {
	return night;
}
public void setNight(String night) {
	this.night = night;
}
public int getSno() {
	return sno;
}
public void setSno(int sno) {
	this.sno = sno;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDepttime() {
	return depttime;
}
public void setDepttime(String depttime) {
	this.depttime = depttime;
}

}
