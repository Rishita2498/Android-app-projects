package com.example.shashank.qrcodescanner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
TextView tv;
Button v;
IntentIntegrator qc;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult result=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);
        if(result!=null)
        {
            if(result.getContents()==null)
            {
                Toast.makeText(this, "there is nothing in QR code", Toast.LENGTH_SHORT).show();
            }
            else
            {
               tv.setText(result.getContents());
            }
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        v=findViewById(R.id.v);
tv=findViewById(R.id.tv);
qc=new IntentIntegrator(MainActivity.this);
v.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        qc.initiateScan();

    }
});
    }
}
