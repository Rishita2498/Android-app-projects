package it.vjit.weatherapp;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Home extends Activity {
Button myforecast;
SharedPreferences sp;
    LocationManager lm;
    LocationListener ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        sp=(SharedPreferences)getSharedPreferences("location",MODE_PRIVATE);
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        ll = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                SharedPreferences.Editor ed=sp.edit();
                ed.putString("lat",location.getLatitude()+"");
                ed.putString("lon",location.getLongitude()+"");

                ed.commit();

            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {

            }

            @Override
            public void onProviderDisabled(String provider) {

            }
        };

        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0.0f, ll);
        myforecast=(Button)findViewById(R.id.forecast);
        myforecast.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
		        startActivity(new Intent(Home.this,ForecastHome.class));	
	
			}
		});
    }
    public void mygps(View v)
    {


        startActivity(new Intent(Home.this,GPSHome.class));
    }
    public void mylocation(View v)
    {
        startActivity(new Intent(Home.this,LocationHome.class));	

    }
 
}
