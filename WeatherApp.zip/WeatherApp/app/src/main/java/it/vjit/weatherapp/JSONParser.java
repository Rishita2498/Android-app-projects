package it.vjit.weatherapp;

import java.io.InputStream;

import org.json.JSONObject;
 
import android.util.Log;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class JSONParser {
 
  static InputStream is = null;
  static JSONObject jObj = null;
  static String json = "";
 
  // constructor
  public JSONParser() {
 
  }
 
  public String getJSONFromUrl(String url) {
 
    // Making HTTP request
    try {
      // defaultHttpClient
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        Response response = client.newCall(request).execute();
        return response.body().string();

    } catch (Exception e) {
      Log.e("Buffer Error", "Error converting result " + e.toString());
    }
 
   
 
    // return JSON String
    return null;
 
  }
}